# Deutsch-spezifische Naturalness Rule Cards

Diese Karten operationalisieren die Muster 7, 8, 13, 45, 54, 55, 58, 60, 61, 63, 64 und 65 sowie registerbezogene Naturalness-Gates. Sie ersetzen keine Cluster-Regel.

## Deixis und Sprecherposition

- Signal: Der Text wechselt zwischen `ich`, `wir`, `man`, neutraler Darstellung und direkter Anrede oder versteckt jede Verantwortlichkeit in Passiv/`man`, obwohl der Texttyp eine klare Sprecherposition braucht.
- Schlechter Reflex: Ich-, Wir- oder Du-Stimme einbauen, weil das "menschlicher" klingt.
- Sicherer Eingriff: vorhandene Sprecherposition stabilisieren; unklare `man`-Sätze nur dann konkretisieren, wenn Akteur und Register im Input erkennbar sind.
- Nicht anfassen: Formal-, Rechts-, Wissenschafts- und Behördentexte, in denen neutrale oder institutionelle Sprecherposition textsortentypisch ist.

## Diskursmarker und pragmatische Haltung

- Signal: Jeder Absatz wird mit logischen Markern wie "daher", "somit", "darüber hinaus" oder "hingegen" verkettet, obwohl der Zusammenhang aus Inhalt und Reihenfolge schon klar ist.
- Schlechter Reflex: Marker durch "ehrlich gesagt", "na ja", "eigentlich" oder andere Haltungssignale ersetzen.
- Sicherer Eingriff: redundante Marker streichen oder Übergang über Thema-Rhema-Anschluss führen; im Locker-Modus höchstens ein passendes Haltungssignal, wenn Ton und Zielprofil es tragen.
- Nicht anfassen: argumentative, wissenschaftliche oder juristische Texte, in denen explizite logische Marker die Leserführung verbessern.

## Verbalstil statt Nominalstil

- Signal: Nominalketten wie "Durchführung der Analyse", "Nutzung von Daten", "Umsetzung der Maßnahmen" verdecken einen vorhandenen Akteur oder Prozess.
- Schlechter Reflex: jedes abstrakte Substantiv in Umgangssprache übersetzen.
- Sicherer Eingriff: nominalisierte Vorgänge in Verben zurückführen, wenn Akteur und Handlung im Text stehen: "die Analyse durchführen" -> "analysieren"; "die Nutzung von" -> "nutzen".
- Nicht anfassen: feste Fachbegriffe, Rechtsbegriffe, wissenschaftliche Terminologie oder bewusst verdichtete Überschriften.

## 7 Dichotomie-Zuspitzung

- Signal: Sätze oder Absatzschlüsse als „nicht X, sondern Y“-Zuspitzung, gehäuft oder als wiederkehrende Pointe. Die Einzelkonstruktion bleibt bewusst Urteil; nur ein dichtes Dokumentcluster läuft als M8-Befund.
- Schlechter Reflex: jede „nicht X, sondern Y“-Konstruktion umschreiben.
- Sicherer Eingriff: nur die gehäufte oder pointierende Wiederholung auflösen und als normale Aussage führen; eine einzelne Gegenüberstellung stehen lassen.
- Nicht anfassen: echte Sachkorrektur („nicht Montag, sondern Dienstag“), einzelner sachlicher Kontrast.

## 8 Negative Parallelismen

- Signal: gepaarte Verneinungsreihen „kein X, kein Y (, nur Z)“ oder „nicht X, nicht Y“ als Rhythmus- oder Pointenmittel. `german_pattern_lint` meldet `negation_parallelism`; dichte Cluster aus „nicht A, sondern B“ oder „A und nicht B“ meldet er als `negation_antithesis_cluster`.
- Schlechter Reflex: jede Verneinung tilgen.
- Sicherer Eingriff: die parallele Reihung in eine normale Aussage auflösen; eine Verneinung genügt meist.
- Nicht anfassen: einzelne Verneinung, „nicht X, sondern Y“-Sachkorrektur, belegte Aufzählung.

## 13 Übermäßige Fettschrift

- Signal: viele `**fett**`-Spannen, oft als Label-Lead-ins vor Listenpunkten. `german_pattern_lint` meldet `bold_overdose` ab fünf Spannen.
- Schlechter Reflex: alle Fettungen entfernen.
- Sicherer Eingriff: Fett auf wenige wirklich tragende Stellen reduzieren; Label-Lead-ins in Fließtext oder eine normale Liste auflösen.
- Nicht anfassen: einzelne bewusste Hervorhebung; Fett in Code oder Tabellen (zählt der Linter ohnehin nicht).

## 45 Anglizismus-Strukturen

- Signal: mehrere wörtlich englische Kollokationen oder Syntaximporte im deutschen Fließtext, etwa „bin ich simpler gegangen“, „die Reibung fällt“, „der Filter bei der Arbeit“ oder englischer Genitiv vor einem Produktnamen.
- Schlechter Reflex: jeden englischen Fachbegriff eindeutschen oder aus einem Einzelvorkommen einen KI-Tell machen.
- Sicherer Eingriff: die deutsche Satzverbindung reparieren und offizielle Namen erhalten, etwa „habe ich es einfacher gehalten“, „die Reibung sinkt“, „der Filter arbeitet“ oder „die Agent Tools von xAI“.
- Nicht anfassen: Code, Zitate, englische Titel, offizielle Produktstrings und etablierte Fachanglizismen ohne auffällige deutsche Anschlusskonstruktion.

## 54 Doppelpunkt-Titel

- Signal: mehrere Titel oder H2 nach demselben `X: Warum/Wie/Was Y`-Schema.
- Schlechter Reflex: jeden Doppelpunkt entfernen.
- Sicherer Eingriff: nur die Wiederholung des Schemas brechen.
- Nicht anfassen: wissenschaftliche Haupttitel mit Untertitel, technische Labels, ein einzelner informativer Doppelpunkt.

## 55 / 61 Rhythmus und Isometrie

- Signal: enge Satzlängen, gleiche Satzanfänge, gleich lange Absätze oder Listen.
- Schlechter Reflex: Füllwörter, Nebenbemerkungen oder falsche Mündlichkeit einstreuen.
- Sicherer Eingriff: vorhandene Sätze teilen oder zusammenziehen, Vorfeld rotieren, Gewichtung an vorhandene Substanz koppeln.
- Nicht anfassen: formale, technische oder juristische Gleichmäßigkeit ohne Lesbarkeitsproblem.

## 58 Abstrakta und Hypernyme

- Signal: Oberbegriffe wie "Maßnahmen", "Aspekte", "Lösungen" ersetzen eine im Text belegte konkrete Sache.
- Schlechter Reflex: Beispiele erfinden.
- Sicherer Eingriff: nur aus vorhandenen Ankern konkretisieren oder `[KONKRETION NOETIG]` markieren.
- Nicht anfassen: echte Sammelbegriffe mit nachfolgender Liste oder fehlender Konkretion.

## 60 Synonym-Rotation

- Signal: mehrere dekorative Beinamen für denselben Referenten.
- Schlechter Reflex: neue Synonyme suchen.
- Sicherer Eingriff: Grundwort plus Pronomen stabilisieren.
- Nicht anfassen: offizieller Beiname mit Informationswert.

## 63 Modalpartikeln

- Signal: partikelarmes Nähe-Register oder Partikel-Überdosis.
- Schlechter Reflex: "ja", "doch", "eben", "halt" über den Text streuen, um Menschlichkeit zu simulieren.
- Sicherer Eingriff: maximal eine passende Partikel pro Absatz im Locker-Modus.
- Nicht anfassen: Sachlich/Formal.

## Anti-Entropy-Reflex

- Signal: Ein Text wirkt gleichförmig, aber inhaltlich korrekt.
- Schlechter Reflex: Satzfragmente, Regelbrüche, Füllwörter, Fehler oder willkürliche seltene Wörter einsetzen, um Vorhersagbarkeit zu senken.
- Sicherer Eingriff: Satzlängen aus vorhandener Aussage spreizen, Vorfeld rotieren, Absätze nach Substanz gewichten und Wiederholungen reduzieren.
- Transparenzpflicht: Erzwungenes Combing kann Burstiness/Mimicry erhöhen und trotzdem Textqualität, Präzision oder Lesbarkeit verschlechtern.
- Nicht anfassen: fachliche Präzision, verständliche Wiederholung, Terminologiekonsistenz oder formale Gleichmäßigkeit ohne Lesbarkeitsproblem.

## 64 KI-Marker-Vokabular

- Signal: Cluster aus Wörtern wie "beleuchten", "nahtlos", "vielschichtig", "ganzheitlich", "dynamische Landschaft".
- Schlechter Reflex: jedes Einzelwort bestrafen.
- Sicherer Eingriff: gewöhnliche Wörter nutzen oder das gemeinte konkrete Feld benennen.
- Nicht anfassen: fachgebundene Verwendung, zum Beispiel robuste Statistik oder dynamisches Routing.

## 65 Kopula-Vermeidung

- Signal: gehauftes "fungiert als", "stellt dar", "verfügt über", "zeichnet sich aus".
- Schlechter Reflex: "ist" und "hat" vermeiden.
- Sicherer Eingriff: auf "ist" oder "hat" zurückführen, wenn keine Information verloren geht.
- Nicht anfassen: echte Funktionsbeschreibung, etwa "dient als Notausgang".

## Scriptseitige Carve-outs
- `register_lint --precise` fängt anaphorisches satzinitiales „Sie“ und Blockquotes wie `> Bitte pruefen Sie das.` ab.
- `german_pattern_lint --precise` fängt `stellt`-Vollverb- und Satzgrenzen-Fälle wie `stellt sicher. ... legte er dar` ab.
- `evidence_lint --precise` filtert Einzeltoken-`proper_name`-Fehlalarme wie `hat Relevanz`.
- Use-Mention bei Muster 64 ist seit P-AP-4 immer abgefangen, auch ohne `--precise`: `"nahtlos"` als Wortbeispiel zählt nicht.

## DACH-Regionalstil

- Signal: Text weicht von Standarddeutsch ab durch regionale Lexik, Syntax oder Registerebene.
- Schlechter Reflex: Österreichisches oder Schweizer Deutsch auf bundesdeutschen Standard korrigieren.
- Sicherer Eingriff: nur wenn der regionale Ausdruck im gewählten Zielkontext eindeutig fehl am Platz ist (z. B. österreichisches Amtsdeutsch in einem bundesdeutschen SEO-Text).
- Nicht anfassen: regionale Lexik mit Informationswert (Greißler, Einkaufszentrum statt Handelszentrum), typisches Register (CH: formal-präzise; AT: historisch-elaboriert; DE: direkt-knapp), Helvetismen in Schweizer Kontexten.
- Merkhilfe: CH = formal und messgenau; AT = historisch und etwas ausladender; DE = direkt und kurz. Alle drei sind authentisch – keines ist KI-Tell.

## QGIR-Stop: akzeptable Textur

- Signal: Nach einem Pass bleiben nur kleine Ecken, Registerspuren oder fachliche Gleichmäßigkeit.
- Schlechter Reflex: noch eine Runde Politur, damit der Text "menschlicher" klingt.
- Sicherer Eingriff: stoppen und Restbefund als toleriert notieren.
- Nicht anfassen: menschlich-holprige, aber belegtreue Sätze; formale Dichte; autorentypische Satzzeichen.
